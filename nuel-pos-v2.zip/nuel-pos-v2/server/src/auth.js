import jwt from 'jsonwebtoken';import bcrypt from 'bcryptjs';import {query} from './db.js';
export const hashPassword=p=>bcrypt.hash(p,12);export const comparePassword=(p,h)=>bcrypt.compare(p,h);
export function token(u){return jwt.sign({id:u.id,name:u.name,username:u.username,role:u.role},process.env.JWT_SECRET,{expiresIn:'12h'});}
export function auth(req,res,next){try{const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))throw 0;req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET);next();}catch{return res.status(401).json({error:'Invalid or expired session.'});}}
export function owner(req,res,next){if(req.user.role!=='Owner')return res.status(403).json({error:'Owner permission required.'});next();}
export async function log(uid,action,details,client= {query}){await client.query(`INSERT INTO activity_logs(user_id,action,details)VALUES($1,$2,$3)`,[uid,action,details]);}
