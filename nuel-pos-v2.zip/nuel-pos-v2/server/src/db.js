import pg from 'pg';import dotenv from 'dotenv';dotenv.config();
const {Pool}=pg;export const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.NODE_ENV==='production'?{rejectUnauthorized:false}:false});
export const query=(text,params)=>pool.query(text,params);
export async function today(client=pool){let r=await client.query(`SELECT * FROM business_days WHERE business_date=CURRENT_DATE LIMIT 1`);if(r.rows[0])return r.rows[0];r=await client.query(`INSERT INTO business_days(business_date)VALUES(CURRENT_DATE)ON CONFLICT(business_date)DO UPDATE SET business_date=EXCLUDED.business_date RETURNING *`);return r.rows[0];}
